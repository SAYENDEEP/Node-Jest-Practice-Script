//two Emitter Q1

var events= require('events');
var eventEmitter =new events.EventEmitter();

var listerner1= function listerner1(){
   console.log("This is the first Listerner");
}
var listerner2= function listerner2(){
    console.log("This is the Second Listerner");
 }

eventEmitter.on('myEmitter',listerner1);
eventEmitter.on('myEmitter',listerner2);
eventEmitter.emit('myEmitter');
//Q2) Display name using event Names
console.log(eventEmitter.eventNames());
