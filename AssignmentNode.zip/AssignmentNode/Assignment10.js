var fs = require("fs");
fs.unlink('data.txt',function(err){
    if(err) throw err;
    console.log("File is deleted...");
})