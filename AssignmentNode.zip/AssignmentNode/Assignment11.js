var fs= require("fs");

fs.mkdirSync('NewFolder');
  console.log(" NewFolder is created");
fs.rmdirSync('NewFolder')
  console.log("New Folder is deleted...")