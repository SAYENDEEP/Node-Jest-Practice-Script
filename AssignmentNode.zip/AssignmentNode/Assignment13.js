var dns = require('dns');
 const readline = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout
});

readline.question('Enter The webiste name', name => {
  dns.lookup(`${name}`, 
     function onLookup(err, address, family) {
    console.log('address:', address);
    dns.reverse(address, function (err, hostnames) {
      console.log('reverse for ' + address + ': ' 
             + JSON.stringify(hostnames));
   });  
});
  
  readline.close();
});