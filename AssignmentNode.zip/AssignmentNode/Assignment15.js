const fs = require('fs');
const employe= require('./employe.json');
const File = fs.readFileSync('./employe.json', 'utf8');
console.log(employe);