var events= require('events');
var eventEmitter= new events.EventEmitter();
var listerner1=  function listerner1(){
      console.log("Listerner1");  
}
var listerner2=  function listerner2(){
    console.log("Listerner2");  
}
eventEmitter.addListener('myListerner',listerner1);
eventEmitter.addListener('myListerner',listerner2);
eventEmitter.emit('myListerner');
console.log("Number of Listerner is:-"+eventEmitter.listenerCount('myListerner'));
console.log("All Listerner that are listening:-",eventEmitter.listeners('myListerner'));
eventEmitter.removeListener('myListerner',listerner2);
console.log("All Listerner that are listening:-",eventEmitter.listeners('myListerner'));

