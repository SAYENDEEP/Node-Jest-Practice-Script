var fs= require('fs');
var fileData="";
var readerStream =fs.createReadStream('practice.txt');

readerStream.on('data',function(readData){
    fileData=readData;
})

readerStream.on('end',function(readData){
  console.log("Data After reading:-"+fileData);   
})

readerStream.on('error',function(err){
    console.log("Error is "+err);   
  })