var fs= require("fs");
const { fromString } = require("long");
fs.readFile("practice.txt",function(err,data){
    var count=0;
    var line=0;
    var i=data.length;
    for(var j=0;j<i;j++){
        if(data.toString().charAt(j)==" ")count++;
        if(data.toString().charAt(j)=="\n")line++;
    }
        word=line+count+1;
        
        console.log("number of line:-"+(line+1));
        console.log("number of words"+word);

   

});

