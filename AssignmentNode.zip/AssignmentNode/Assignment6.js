var readline= require('readline-sync');
var fs= require("fs");
var data=0;
searchstring=readline.question("Enter a String to search:-");

let flag=0;
fs.readFile("practice.txt",function(err,data){
    if(err)throw err;
    if(data.includes(searchstring)){
        console.log("Your String is found")
        flag=1;
    }
    if(flag==0){
          console.log("Your string is not found");
    }
});