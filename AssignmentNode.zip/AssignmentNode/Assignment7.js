var readline= require('readline-sync');
var fs= require("fs");
var data=0;
searchstring=readline.question("Enter a String to search:-");

var flag=0;
var count=0;

fs.readFile("practice.txt",function(err,data){
  var input1= data.toString();
  var inputarr=input1.split("\n").join(",").split(" ").join(",").split(",");
  
for(var i=0;i<inputarr.length;i++){

      if(searchstring==inputarr[i]){
          count++;
      }
  }
  console.log("Total count of the Search String:-"+count);
});