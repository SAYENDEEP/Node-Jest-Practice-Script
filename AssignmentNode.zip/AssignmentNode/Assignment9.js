const fs = require("fs");

const src = "practice.txt";
const dest = "copy1.txt";
fs.copyFile(src, dest, (error) => {
  if (error) {
    console.error(error);
    return;
  }

  console.log("Copied Successfully!");
});