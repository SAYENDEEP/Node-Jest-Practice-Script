const { returnURL } = require("./Matchers");

    function sum(a,b){
        return  a+b;
   }
   function substract(a,b){
       return a-b;
   }
   function multiply(a,b){
    return a*b;
}
function divide(a,b){
    return a/b;
}
var a=10
function larger(a,b){
    if(a>b)
      return a;
    else
       return b;
}
function largest3number(a,b,c){
    if(a>b && a>c)
      return a;
    else if(b>c)
      return b;
    else
     return c;
}
function Factorial(a){
    var fact=1;
   for(i=1;i<=a;i++){
       fact =fact*i;
   }
   return fact;
}
function EvenOdd(value){
    if(value%2==0)
      return true;
    else
      return false;
}
function LargestArr(arr){
   var largest =arr[0];
   for(var i=0;i<arr.length;i++){
       if(largest<arr[i]){
           largest=arr[i];
       }
   }
   return largest;
}
function SearchElement(arr,n1){
    var flag=0;
    for(var i=0;i<arr.length;i++){
        if(arr[i]==n1)
        {
            flag=1;
            return true;
        }
    }
    if(flag==0)
      return false;
}
module.exports.sum=sum;
module.exports.substract=substract;
module.exports.multiply=multiply;
module.exports.divide=divide;
module.exports.larger=larger;
module.exports.largest3number=largest3number;
module.exports.Factorial=Factorial;
module.exports.EvenOdd=EvenOdd;
module.exports.LargestArr=LargestArr;

   
