var matchers = require("./Calculator")
    test("Sum of two number",()=>{
        expect(matchers.sum(2,3)).toBe(5);
    })
    test("Substract of two number",()=>{
     expect(matchers.substract(3,6)).toBe(-3);
    })
    test("Multiply of two number",()=>{
        expect(matchers.multiply(2,3)).toBe(6);
    })
    test("Divide of two number",()=>{
        expect(matchers.divide(10,2)).toBe(5);
    })
    test("Largest of 2 numbers",()=>{
         
        expect(matchers.larger(2,3)).toBe(3);
    })
    test("Largest of 3 number",()=>{
        expect(matchers.largest3number(6,8,4)).toBe(8);
    })
    test("Factorial of number",()=>{
        expect(matchers.Factorial(5)).toBe(120);
    })
    test("Even and Odd",()=>{
        expect(matchers.EvenOdd(10)).toBeTruthy();
        expect(matchers.EvenOdd(5)).toBeFalsy();
    })
    test("Largest  of two number",()=>{
        expect(matchers.EvenOdd(10)).toBeTruthy();
    })
    test("Largest element in the array",()=>{
       expect(matchers.LargestArr([10,15,16,78,16,18])).toBe(78);
    })
    test("Element in the array",()=>{
        expect(matchers.LargestArr([10,15,16,78,16,18])).toBe(78);
     })
     test("Search a element in a array",()=>{
        expect(matchers.LargestArr([10,15,16,78,16,18],15)).toBeTruthy();
     })
    


