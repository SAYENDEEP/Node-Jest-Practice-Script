var arr=[
    {"bookid":1,"bookname":"RubicCube","author":"Robart Brown","cost":1599},
    {"bookid":2,"bookname":"SquareMaze","author":"Silly Thomas","cost":599},
    {"bookid":3,"bookname":"Spacex","author":"Rupam Kar","cost":1999},
    {"bookid":4,"bookname":"Beyond","author":"Jitin Sikar","cost":2999},
    {"bookid":5,"bookname":"Mystry in the market","author":"Jevam Raj","cost":1399},

]
function check(id1){
    var flag=0;
  arr.forEach((element)=>{
    //   console.log(element);
    //   console.log(id);
      if(element.bookid===id1)
      {
          flag=1;
          return element;
      }
  })
  if(flag==0){
      return null;
  }
     
}
function searchArrById(){
    return arr.map(data=>data.bookid);
}
module.exports.check=check;
module.exports.searchArrById=searchArrById;