
var checkLibrary= require('./Library')
test("Checking if bookrecord is send or not",()=>{
    var  bookid1= checkLibrary.check(1);
    var  bookid2= checkLibrary.check(8);
    console.log("Return data from the function is"+JSON.stringify(bookid1));
    console.log("Return data from the function is"+JSON.stringify(bookid2));
    expect(bookid2).toBeNull();
    expect(bookid1).not.toBeNull();
})
test("Checking if bookid  is present or not",()=>{
expect(checkLibrary.searchArrById()).toContain(2);
})