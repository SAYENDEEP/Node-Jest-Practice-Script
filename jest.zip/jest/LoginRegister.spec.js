const LoginRegister =require("./LoginRegister");

test("check login validation",()=>{
    expect(LoginRegister.login("user3","4321")).toBe("Valid User");
})
test("check Signup validation",()=>{
    expect(LoginRegister.register("user8","3456","admin")).toBe("Registration is successful");
})