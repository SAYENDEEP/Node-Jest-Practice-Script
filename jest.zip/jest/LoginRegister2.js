var arr=[
    {"username":"user1","password":"123","role":"admin"},
    {"username":"user2","password":"321","role":"user"},
    {"username":"user3","password":"4321","role":"admin"},
    {"username":"user4","password":"say@123","role":"admin"},
    {"username":"user5","password":"pen","role":"user"}
 ]
 
 function login1(username1,password1){
     var flag=0;
     arr.forEach((element)=>{
         //   console.log(element);
         //   console.log(id);
           if(element.username===username1 && element.password===password1)
           {
               flag=1;
               
           }
       })
       if(flag==1){
           return "Valid User";
       }
       else{
           return "Invalid User";
       }
          
  }
  function register1(username2,password2,role2){
     if(username2!=null && password2!=null && role2!=null){
         arr.push({"username":username2,"password":password2,"role":role2})
        //  console.log(arr);
         return "Registration is successful";
     }
     else{
      return "Registration is failed";
     }
     
  }
  module.exports.login1=login1;
  module.exports.register1=register1;
 
 
 