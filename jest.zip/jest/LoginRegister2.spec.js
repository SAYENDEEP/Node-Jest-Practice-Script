const LoginRegister2 =require("./LoginRegister2");


test("check Signup validation",()=>{
    expect(LoginRegister2.register1("user9","32145","admin")).toBe("Registration is successful");
    expect(LoginRegister2.register1("user10","8908","user")).toBe("Registration is successful");
})
test("check login validation",()=>{
    expect(LoginRegister2.login1("user9","32145")).toBe("Valid User");
    expect(LoginRegister2.login1("user10","8908")).toBe("Valid User");
})