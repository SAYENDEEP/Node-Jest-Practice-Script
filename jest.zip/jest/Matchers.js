const Matchers =
{
    returnObject : function(){
        var empObj ={"id":104,"name":"Sayendeep","dept":"CSE","designation":"Full Stack Developer"}
        return empObj;
    },
    returnURL:function(){
        var strURL="https://www.google.com/";
        return strURL;

    },
    returnArrNames:function(){
        var strArr=['Sayendeep','Ram','Mohan','Sita','Reeva'];
        return strArr;
    }
} 
module.exports=Matchers