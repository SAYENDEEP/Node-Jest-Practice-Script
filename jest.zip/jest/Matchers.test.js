const { TestWatcher } = require("@jest/core")
var matchers = require("./Matchers")

describe('Matchers Suite',()=>{
    test("Comparing Objects with toBe() and toEqual()",()=>{
      var empObj={"id":104,"name":"Sayendeep","dept":"CSE","designation":"Full Stack Developer"}
      expect(matchers.returnObject()).toEqual(empObj);
    //   expect(matchers.returnObject()).toBe(empObj);
    })
    test("to use Matcher .not toBeNull() with an object",()=>{
        var empObj =matchers.returnObject();
        expect(empObj).not.toBeNull();
    })
    test('Use the Matchers tobeTruthy() anfd toBeFalsy()',()=>{
        // var bData =true;
        // expect(bData).toBeTruthy();
        var empObj=matchers.returnObject();
        expect(empObj).toBeTruthy();

        empObj =null;
        expect (empObj).toBeFalsy();
    })
    test('to Use Matcher to match',()=>{
    
        var strUrl="https://www.google.com/";
        expect(matchers.returnURL()).toMatch(strUrl);
    })
    test('to Use Matcher toContain() and checking the content of the array for a name',()=>{
        var strNameToSearchFor='Sayendeep';
        expect(matchers.returnArrNames()).toContain(strNameToSearchFor);
    })
    beforeEach(()=>{
        console.log("This  BeforeEach Function");
    })
    afterEach(()=>{
        console.log("This is After Each");
    })

    beforeAll(()=>{
        console.log("Before All function");
    })
    afterAll(()=>{
        console.log("AfterAll() Function");
    })
})